/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
package com.mycompany.quickchats3;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

/**
 *
 * @author Horace
 */
public class QuickChats3IT {
    
    public QuickChats3IT() {
    }

    @org.junit.jupiter.api.Test
    public void testMain() {
    }

    @org.junit.jupiter.api.Test
    public void testRegisterUser() {
    }

    @org.junit.jupiter.api.Test
    public void testLoginUser() {
    }

    @org.junit.jupiter.api.Test
    public void testRunMainMenu() {
    }

    @org.junit.jupiter.api.Test
    public void testSendMessages() {
    }

    @org.junit.jupiter.api.Test
    public void testMessageManagerMenu() {
    }

    @org.junit.jupiter.api.Test
    public void testDisplaySendersAndRecipients() {
    }

    @org.junit.jupiter.api.Test
    public void testDisplayLongestMessage() {
    }

    @org.junit.jupiter.api.Test
    public void testSearchByMessageID() {
    }

    @org.junit.jupiter.api.Test
    public void testSearchByRecipient() {
    }

    @org.junit.jupiter.api.Test
    public void testDeleteByMessageHash() {
    }

    @org.junit.jupiter.api.Test
    public void testDisplayReport() {
    }

    @org.junit.jupiter.api.Test
    public void testGenerateMessageID() {
    }

    @org.junit.jupiter.api.Test
    public void testGenerateMessageHash() {
    }

    @org.junit.jupiter.api.Test
    public void testDisplayMessageDetails() {
    }

    @org.junit.jupiter.api.Test
    public void testWriteMessageToJSON() {
    }
    
}
