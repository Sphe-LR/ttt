/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.quickchats3;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import javax.swing.JOptionPane;
/**
 *
 * QuickChats3 - Created by MNISI SM
 * 
 * This class stores user details and manages history .
 * It keeps track of message sent, message IDs, and recipients 
 * Developed as part of my personal QuickChats project.
 */
public class QuickChats3 {
// === Register User Information ( Mnisi SM)===
    static String registeredUsername;
    static String registeredPassword;
    static String registeredPhone;
 
 //   === Tracking Sent Message Counts ===
    static int totalMessagesSent = 0;
    static int messageNumber = 0;
 
    // === Data Structure for Message Handling (Mnisi's QuickChats System)  ===
    static ArrayList<String> sentMessages = new ArrayList<>();
    static ArrayList<String> disregardedMessages = new ArrayList<>();
    static ArrayList<String> storedMessages = new ArrayList<>();
    static ArrayList<String> recipients = new ArrayList<>();
    static ArrayList<String> messageIDs = new ArrayList<>();
    static ArrayList<String> messageHashes = new ArrayList<>();
    
    
    
    public static void main(String[] args) {
        // === Welcome to Mnisi's QuickChat ===
      JOptionPane.showMessageDialog(null, "Welcome to QuickChat!");
      
        // === Begin User Registration === 
        registerUser();
        // === Attempt login ===
        if (loginUser()) {
            JOptionPane.showMessageDialog(null, "Login successful. Redirecting to QuickChat...");
            runMainMenu();
        } else {
            JOptionPane.showMessageDialog(null, "Login failed. Exiting app.");
        }
    }
 
    public static void registerUser() {
        boolean valid = false;
         // User Registraction Loop 
        while (!valid) {
            // --- Username Creation 
            registeredUsername = JOptionPane.showInputDialog(
                    "Create a username (must contain _ and max 5 chars):");
                        
            if (!(registeredUsername != null && registeredUsername.contains("_") && registeredUsername.length() <= 5)) {
                JOptionPane.showMessageDialog(null, "Invalid username.");
                continue;
            }
            // --- Password creation ---
            registeredPassword = JOptionPane.showInputDialog("Create password (8+ chars, 1 capital, 1 number, 1 special):");
            if (!(registeredPassword != null && registeredPassword.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).{8,}$"))) {
                JOptionPane.showMessageDialog(null, "Invalid password.");
                continue;
            }
            // --- Phone number entry 
            registeredPhone = JOptionPane.showInputDialog("Enter phone number (+27xxxxxxxxx):");
            if (!(registeredPhone != null && registeredPhone.matches("^\\+27[6-8]\\d{8}$"))) {
                JOptionPane.showMessageDialog(null, "Invalid phone number.");
                continue;
            }
            // --- Succesful registration ---
            JOptionPane.showMessageDialog(null, "Registration successful!");
            valid = true;
        }
    }
 
    public static boolean loginUser() {
        //  renamed 'user' → 'username' and 'pass' → 'password' for clarity

        String user = JOptionPane.showInputDialog("Login - Enter your username:");
        String pass = JOptionPane.showInputDialog("Enter your password:");
        return user != null && pass != null && user.equals(registeredUsername) && pass.equals(registeredPassword);
    }
 
    // Main menu with message and management option 
    public static void runMainMenu() {
        boolean isRunning  = true;
        
        while (isRunning) {
            String[] options = {
                "Send Messages",
                "Message Manager",
                "Quit"
            };
            int choice = JOptionPane.showOptionDialog(null, "CLARIFY :", "Main Menu",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.INFORMATION_MESSAGE, null, options, options[0]);
 
            switch (choice) {
                case 0 -> sendMessages();
                case 1 -> messageManagerMenu();
                case 2, JOptionPane.CLOSED_OPTION -> {
                    isRunning = false;
                    JOptionPane.showMessageDialog(null, "Goodbye!");
                }
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
 
        //  Handles sending multiple messages ( some functionality , clearer comments )
    public static void sendMessages() {
        //  Ask user how many messages they want to send 
        String inputCount = JOptionPane.showInputDialog("How many messages would you like to send?");
        if (inputCount == null) return;
        
        
        int messagecount;
        try {
           messagecount = Integer.parseInt(inputCount);
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Invalid number.");
            return;
        }
        // Loop for each message to send 
        for (int i = 0; i < messagecount; i++) {
            messageNumber++; // keep track of message sequence 
            String messageID = generateMessageID();
            
            
            // Request recipient number input
            String recipient = JOptionPane.showInputDialog("Enter recipient number (+27xxxxxxxxx):");
            if (recipient == null || !recipient.matches("^\\+27\\d{9}$")) {
                JOptionPane.showMessageDialog(null, "Invalid number format.");
                i--; // retry curret iteration
                continue;
            }
             // Request message text input 
            String message = JOptionPane.showInputDialog("Enter message (max 250 characters):");
            if (message == null) {
                i--; // retry if cancelled
                continue;
                
                
            }
            
             // Enforce character limit
            if (message.length() > 250) {
                JOptionPane.showMessageDialog(null, 
                        "Message too long by " + (message.length() - 250) + " characters.");
                i--;  // retry if too long 
                continue;
            }
            
               
            
            // Generate a hash for the message using message ID, number,and content    
            String hash = generateMessageHash(messageID, messageNumber, message);
            
            
            // Define the possible user actions 
            String[] actions = {"Send", "Disregard", "Store"};
            
            
            // Display an option dialog for user choice 
            int action = JOptionPane.showOptionDialog(null,
                    "What do you want to do?", 
                    "Message Options",
                    JOptionPane.DEFAULT_OPTION, 
                    JOptionPane.INFORMATION_MESSAGE,
                    null, 
                    actions,
                    actions[0]);
              //  Handles user actions selections 
            switch (action) {
                case 0 -> {
                    // Increased sent message count 
                    totalMessagesSent++;
                    // Add message details to the corresponding lists 
                    sentMessages.add(message);
                    recipients.add(recipient);
                    messageIDs.add(messageID);
                    messageHashes.add(hash);
                    
                    
                   // Display confirmation and message details 
                    displayMessageDetails(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message successfully sent.");
                }
                case 1 -> {
                    // store disregarding messages 
                    disregardedMessages.add(message);
                    JOptionPane.showMessageDialog(null, "Message disregarded.");
                }
                case 2 -> {
                    // store messages in local storage or file 
                    storedMessages.add("Recipient: " + recipient + " | Message: " + message);
                    writeMessageToJSON(messageID, hash, recipient, message);
                    JOptionPane.showMessageDialog(null, "Message stored.");
                }
                default -> {
                    // Handle unexpected or no selection
                    JOptionPane.showMessageDialog(null, "No action taken.");
                    // optionally decrement loop counter if used in a loop 
                    i--;
                }
            }
        }
        JOptionPane.showMessageDialog(null, "Total messages sent: " + totalMessagesSent);
    }
 
    // === GUI-Based Message Manager Menu ===
    public static void messageManagerMenu() {
        boolean running = true; // Flag to keep the menu active
        
        
        
        while (running) {
         // Available options for managing message   
    
            String[] options = {
                "Display all sent messages",
                "Display longest sent message",
                "Search by Message ID",
                "Search messages by recipient",
                "Delete message by hash",
                "Show full report",
                "Back to Main Menu"
            };
            
            // Display the Message Manager menu to the user 
            int choice = JOptionPane.showOptionDialog(
                    null,
                    "Select an option below:",
                    "Message Manager",
                    JOptionPane.DEFAULT_OPTION,
                    JOptionPane.INFORMATION_MESSAGE, 
                    null,
                    options,
                    options[0]);
            // Handle user selection 
            switch (choice) {
               
                case 0 -> displaySendersAndRecipients(); // show all messages and recipients 
                case 1 -> displayLongestMessage();  // Display the message with the most characters 
                case 2 -> {
                    // Search foe a message using uinque ID 
                    String id = JOptionPane.showInputDialog("Enter Message ID:");
                    if (id != null) searchByMessageID(id);
                }
                case 3 -> {
                    // Search for message by the recipients number 
                    String recipient = JOptionPane.showInputDialog("Enter Recipient Number:");
                    if (recipient != null) searchByRecipient(recipient);
                }
                case 4 -> {
                    // Delete a message based on its hash 
                    String hash = JOptionPane.showInputDialog("Enter Message Hash:");
                    if (hash != null) deleteByMessageHash(hash);
                }
                case 5 -> displayReport(); // Show a coplete report of all sorted stored data 
                case 6, JOptionPane.CLOSED_OPTION -> running = false;
                // Exit the message Manager return to the main menu
                default -> JOptionPane.showMessageDialog(null, "Invalid choice.");
            }
        }
    }
 
    // === Message Manager utility methods ===
    
    
    
    
    /**
     * Display all send messages along with their associated recipients , hash , and ID .
     * If there are sent messages, a notification dialog is shown. 
     * Created by SM MNISI
     */
    public static void displaySendersAndRecipients() {
        // Check if there are any sent messages
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to display.");
            return;
        }
        
        
        // Build a formatted list all sent messages 
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("---------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Sent Messages", JOptionPane.INFORMATION_MESSAGE);
    }
 
    public static void displayLongestMessage() {
        // Check if there are any messages available 
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages.");
            return;
        }
        // Find the longest message in the list 
        String longest = "";
        for (String msg : sentMessages) {
            if (msg.length() > longest.length()) {
                longest = msg;
            }
        }
        JOptionPane.showMessageDialog(null, "Longest Sent Message:\n" + longest);
    }
 // Display the longest 
    public static void searchByMessageID(String id) {
        for (int i = 0; i < messageIDs.size(); i++) {
            if (messageIDs.get(i).equals(id)) {
                String msgDetails = "Recipient: " + recipients.get(i) + "\nMessage: " + sentMessages.get(i);
                JOptionPane.showMessageDialog(null, msgDetails, "Search Result", JOptionPane.INFORMATION_MESSAGE);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message ID not found.");
    }
 
    public static void searchByRecipient(String recipientNumber) {
        StringBuilder sb = new StringBuilder("Messages to " + recipientNumber + ":\n");
        boolean found = false;
        for (int i = 0; i < recipients.size(); i++) {
            if (recipients.get(i).equals(recipientNumber)) {
                sb.append(sentMessages.get(i)).append("\n");
                found = true;
            }
        }
        for (String stored : storedMessages) {
            if (stored.contains(recipientNumber)) {
                sb.append(stored).append("\n");
                found = true;
            }
        }
        if (!found) {
            JOptionPane.showMessageDialog(null, "No messages found for recipient: " + recipientNumber);
        } else {
            JOptionPane.showMessageDialog(null, sb.toString(), "Messages by Recipient", JOptionPane.INFORMATION_MESSAGE);
        }
    }
 
    public static void deleteByMessageHash(String hash) {
        for (int i = 0; i < messageHashes.size(); i++) {
            if (messageHashes.get(i).equals(hash)) {
                String msg = sentMessages.get(i);
                sentMessages.remove(i);
                recipients.remove(i);
                messageIDs.remove(i);
                messageHashes.remove(i);
                JOptionPane.showMessageDialog(null, "Deleted message:\n" + msg);
                return;
            }
        }
        JOptionPane.showMessageDialog(null, "Message hash not found.");
    }
 
    public static void displayReport() {
        if (sentMessages.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No sent messages to report.");
            return;
        }
        StringBuilder sb = new StringBuilder("===== SENT MESSAGE REPORT =====\n");
        for (int i = 0; i < sentMessages.size(); i++) {
            sb.append("Message ID: ").append(messageIDs.get(i)).append("\n");
            sb.append("Message Hash: ").append(messageHashes.get(i)).append("\n");
            sb.append("Recipient: ").append(recipients.get(i)).append("\n");
            sb.append("Message: ").append(sentMessages.get(i)).append("\n");
            sb.append("-----------------------------\n");
        }
        JOptionPane.showMessageDialog(null, sb.toString(), "Message Report", JOptionPane.INFORMATION_MESSAGE);
    }
 
    // === Helper methods from Code 1 ===
    public static String generateMessageID() {
        return String.format("%010d", new Random().nextInt(1_000_000_000));
    }
 
    public static String generateMessageHash(String id, int num, String msg) {
        String[] words = msg.trim().split(" ");
        String first = words.length > 0 ? words[0] : "";
        String last = words.length > 1 ? words[words.length - 1] : "";
        return (id.substring(0, 2) + ":" + num + ":" + first + last).toUpperCase();
    }
 
    public static void displayMessageDetails(String id, String hash, String recipient, String message) {
        JOptionPane.showMessageDialog(null,
                "Message ID: " + id +
                        "\nHash: " + hash +
                        "\nRecipient: " + recipient +
                        "\nMessage: " + message);
    }
 
    public static void writeMessageToJSON(String messageID, String hash, String recipient, String message) {
        StringBuilder jsonEntry = new StringBuilder();
        jsonEntry.append("{\n");
        jsonEntry.append("  \"MessageID\": \"").append(messageID).append("\",\n");
        jsonEntry.append("  \"MessageHash\": \"").append(hash).append("\",\n");
        jsonEntry.append("  \"Recipient\": \"").append(recipient).append("\",\n");
        jsonEntry.append("  \"Message\": \"").append(message.replace("\"", "\\\"")).append("\"\n");
        jsonEntry.append("},\n");
 
        try (FileWriter file = new FileWriter("Jsonnew.json", true)) { // append mode
            file.write(jsonEntry.toString());
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing file: " + e.getMessage());
        }
    }
}
        
        
     
